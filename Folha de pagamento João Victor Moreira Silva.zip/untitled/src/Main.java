import java.util.Scanner;
import java.util.ArrayList;
import java.util.Set;

public class Main {
    static final double SALARIO_BASE=2000.00;

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<colaborador> lista = new ArrayList<>();
        int opcao;
        do {
            System.out.println("\n=== MENU ===");
            System.out.println("1 - cadastrar funcionario padrão");
            System.out.println("2 - cadastrar funcionario Comissionado");
            System.out.println("3 - cadastrar funcionario de Produção");
            System.out.println("4 - Gerar Folha de Pagamento");
            System.out.println("0 - Sair");
            System.out.println("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Número de registro: ");
                    int registro=scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("nome completo: ");
                    String nome= scanner.nextLine();

                    colaborador c1=new colaborador(registro,nome, "padrão",SALARIO_BASE);
                    lista.add(c1);
                    System.out.println("Funcionário cadastrado com sucesso!");
                    break;

                case 2:
                    System.out.print("Número de registro: ");
                    int registro2= scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("nome completo: ");
                    String nome2= scanner.nextLine();
                    System.out.print("total de vendas no mês: ");
                    double vendas=scanner.nextDouble();
                    System.out.print("percentual de comissão: ");
                    double percentual=scanner.nextDouble();

                    double comissao= vendas*percentual/100;
                    double salario2= SALARIO_BASE+comissao;
                    colaborador c2= new colaborador(registro2, nome2, "comissionado", salario2);
                    c2.setTotalvendas(vendas);
                    c2.setPercentualComissao(percentual);
                    lista.add(c2);
                    System.out.println("Funcionário cadastrado com sucesso! ");
                    break;

                case 3:
                    System.out.print("Número de registro: ");
                    int registro3= scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nome completo: ");
                    String nome3= scanner.nextLine();
                    System.out.print("Valor por peça: ");
                    double ValorPeca = scanner.nextDouble();
                    System.out.print("quantidade produzida: ");
                    double qtd = scanner.nextDouble();

                    double bonus = ValorPeca * qtd;
                    double salario3 = SALARIO_BASE + bonus;

                    colaborador c3= new colaborador(registro3, nome3, "produção", salario3);
                    c3.setValorPorPeca(ValorPeca);
                    c3.setQuantidadeProduzida(qtd);
                    lista.add(c3);
                    System.out.println("Funcionário cadastrado com sucesso! ");
                    break;

                case 4:
                    System.out.println("\n=== FOLHA DE PAGAMENTO ===");
                    if (lista.isEmpty()) {
                        System.out.println("nenhum colaborador cadastrado!");
                    }else {
                        for (colaborador c :lista) {
                            System.out.println("-----------");
                            System.out.println("Registro: " + c.getRegistro());
                            System.out.println("nome: " + c.getNome());
                            System.out.println("Tipo: " + c.getTipovinculo());
                            System.out.println("Salário Final: " + c.getSalariofinal());
                        }
                        System.out.println("---------------");
                    }
                    break;
                case 0:
                    System.out.println(">> Encerrando...");
                    break;
                default:
                    System.out.println(">> Opção inválida!");
            }
        } while (opcao != 0);
    }
}
