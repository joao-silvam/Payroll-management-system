public class colaborador{
    private int registro;
    private String nome;
    private String tipovinculo;
    private double salariofinal;
    private double totalvendas;
    private double percentualComissao;
    private double valorPorPeca;
    private double quantidadeProduzida;

    public colaborador(int registro, String nome, String tipoVinculo, double salarioFinal) {
        this.registro = registro;
        this.nome = nome;
        this.tipovinculo = tipoVinculo;
        this.salariofinal = salarioFinal;
        this.totalvendas = 0;
        this.percentualComissao = 0;
        this.valorPorPeca = 0;
        this.quantidadeProduzida = 0;
    }
    public int getRegistro(){
        return registro;
    }
    public String getNome() {
        return nome;
    }
    public String getTipovinculo() {
        return tipovinculo;
    }
    public double getSalariofinal() {
        return salariofinal;
    }

    public double getTotalvendas() {
        return totalvendas;
    }

    public double getPercentualComissao() {
        return percentualComissao;
    }

    public double getValorPorPeca() {
        return valorPorPeca;
    }

    public double getQuantidadeProduzida() {
        return quantidadeProduzida;
    }

    public void setRegistro(int registro){
        this.registro=registro;
    }
    public void setNome(String nome){
        this.nome=nome;
    }
    public void setTipovinculo(String tipovinculo){
        this.tipovinculo=tipovinculo;
    }
    public void setSalariofinal(Double salariofinal){
        this.salariofinal=salariofinal;
    }
    public void setTotalvendas(double totalvendas){
        this.totalvendas=totalvendas;
    }
    public void setPercentualComissao(double percentualComissao) {
        this.percentualComissao = percentualComissao;
    }

    public void setValorPorPeca(double valorPorPeca) {
        this.valorPorPeca = valorPorPeca;
    }

    public void setQuantidadeProduzida(double quantidadeProduzida) {
        this.quantidadeProduzida = quantidadeProduzida;
    }
}